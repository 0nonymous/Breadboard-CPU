data = bytearray([
    # 'A'
    0b00000000,
    0b00011100,
    0b00110110,
    0b01100011,
    0b01100011,
    0b01111111,
    0b01100011,
    0b01100011, 
])
with open("character.bin", "wb") as file:
    file.write(data)
