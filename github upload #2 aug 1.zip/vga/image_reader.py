# based off of ben eater's python program from "World's worst video card? The exciting conclusion"
from PIL import Image

image = Image.open("characters.png")
pixels = image.load()
out_file = open("image.bin", "wb")
data = bytearray([])

for z in range(26):
    for y in range(8):
        temp = 0
        for x in range(8):
            if (pixels[z*8 + (8-x), y] == 0 or pixels[z*8 + (8-x), y] == 1):
                print(" ", end="")
                temp =2*temp
            else:
                print("@", end="")
                temp =2*temp + 1
        print(hex(temp))
        data.append(temp)


with open("image.bin", "wb") as file:
    file.write(data)

